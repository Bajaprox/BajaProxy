
public class StringObject {
    private String value;

    public StringObject(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int length() {
        return value.length();
    }

    public boolean isEmpty() {
        return value == null || value.trim().isEmpty();
    }

    public StringObject concat(String str) {
        return new StringObject(this.value + str);
    }

    public StringObject toLowerCase() {
        return new StringObject(value.toLowerCase());
    }

    public StringObject toUpperCase() {
        return new StringObject(value.toUpperCase());
    }

    public StringObject trim() {
        return new StringObject(value.trim());
    }

    public boolean contains(String substring) {
        return value.contains(substring);
    }

    public String[] split(String delimiter) {
        return value.split(delimiter);
    }

    public StringObject replace(String target, String replacement) {
        return new StringObject(value.replace(target, replacement));
    }

    public int indexOf(String str) {
        return value.indexOf(str);
    }

    @Override
    public String toString() {
        return value;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        StringObject that = (StringObject) obj;
        return value != null ? value.equals(that.value) : that.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }
}
