from typing import Dict
import uuid

class AIProcessManager:
    def __init__(self):
        self.processes: Dict = {}
        
    def create_process(self, process_type: str, config: Dict) -> str:
        process_id = str(uuid.uuid4())
        self.processes[process_id] = {
            "type": process_type,
            "config": config,
            "status": "initialized"
        }
        return process_id
    
    def start_process(self, process_id: str) -> bool:
        if process_id in self.processes:
            self.processes[process_id]["status"] = "running"
            return True
        return False
    
    def stop_process(self, process_id: str) -> bool:
        if process_id in self.processes:
            self.processes[process_id]["status"] = "stopped"
            return True
        return False
    
    def get_process_status(self, process_id: str) -> Dict:
        return self.processes.get(process_id, {"status": "not_found"})