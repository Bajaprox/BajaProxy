from py3 import AISystem

def main():
    ai_system = AISystem()
    
    while True:
        command = input("Enter AI command: ")
        if command.lower() == "exit":
            break
            
        result = ai_system.run_command(command)
        print(f"Result: {result}")

if __name__ == "__main__":
    main()