
class Baja:
    def __init__(self, name="Baja"):
        self.name = name
        self.commands = []
        self.responses = []
        
    def send_command(self, command):
        self.commands.append(command)
        # Process command and generate response
        response = f"{self.name} processed: {command}"
        self.responses.append(response)
        return response
        
    def get_history(self):
        history = []
        for cmd, resp in zip(self.commands, self.responses):
            history.append((cmd, resp))
        return history
        
    def clear_history(self):
        self.commands = []
        self.responses = []
        
    def get_name(self):
        return self.name
