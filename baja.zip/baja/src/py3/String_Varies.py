
def string_variations(text):
    """Generate variations of a string for AI processing"""
    variations = []
    
    # Original text
    variations.append(text)
    
    # Lowercase variation
    variations.append(text.lower())
    
    # Uppercase variation
    variations.append(text.upper())
    
    # Title case variation
    variations.append(text.title())
    
    # Remove extra whitespace
    cleaned = ' '.join(text.split())
    variations.append(cleaned)
    
    # Remove punctuation
    import string
    no_punct = text.translate(str.maketrans('', '', string.punctuation))
    variations.append(no_punct)
    
    # Alphanumeric only
    alpha_num = ''.join(c for c in text if c.isalnum())
    variations.append(alpha_num)
    
    # Replace spaces with underscores
    underscored = text.replace(' ', '_')
    variations.append(underscored)
    
    # Remove duplicates while preserving order
    return list(dict.fromkeys(variations))

def normalize_string(text):
    """Normalize string for consistent AI processing"""
    # Convert to lowercase
    text = text.lower()
    
    # Remove extra whitespace
    text = ' '.join(text.split())
    
    # Remove special characters
    text = ''.join(c for c in text if c.isalnum() or c.isspace())
    
    return text

def get_string_tokens(text):
    """Split string into tokens for AI analysis"""
    # Split on whitespace
    tokens = text.split()
    
    # Remove empty tokens
    tokens = [t for t in tokens if t]
    
    # Normalize each token
    tokens = [normalize_string(t) for t in tokens]
    
    return tokens
