from process import AIProcessor
from Commands import AIInterpreter
from MultProcess import AIProcessManager

class AISystem:
    def __init__(self):
        self.processor = AIProcessor()
        self.interpreter = AIInterpreter()
        self.process_manager = AIProcessManager()
        
        # Register basic commands
        self.interpreter.register_command("process", self._handle_process)
        self.interpreter.register_command("status", self._handle_status)
    
    def _handle_process(self, params):
        process_id = self.process_manager.create_process("standard", {})
        self.processor.submit_task(process_id, params)
        return {"process_id": process_id}
    
    def _handle_status(self, params):
        if params:
            return self.process_manager.get_process_status(params[0])
        return {"error": "Process ID required"}

    def run_command(self, command: str):
        return self.interpreter.interpret(command)