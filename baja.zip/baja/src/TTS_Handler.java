
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TTS_Handler {
    private static Voice voice;
    private static final String VOICE_NAME = "kevin16";

    public TTS_Handler() {
        System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
        VoiceManager voiceManager = VoiceManager.getInstance();
        voice = voiceManager.getVoice(VOICE_NAME);
        voice.allocate();
    }

    public void speak(String text) {
        if (voice != null) {
            voice.speak(text);
        }
    }

    public void stopSpeaking() {
        if (voice != null) {
            voice.deallocate();
        }
    }

    public boolean isSpeaking() {
        return voice != null && voice.isLoaded();
    }

    public void setVolume(float volume) {
        if (voice != null) {
            voice.setVolume(volume);
        }
    }

    public void setPitch(float pitch) {
        if (voice != null) {
            voice.setPitch(pitch);
        }
    }

    public void setRate(float rate) {
        if (voice != null) {
            voice.setRate(rate);
        }
    }
}
