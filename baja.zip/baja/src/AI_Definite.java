
import java.net.InetSocketAddress;
import java.net.Proxy;

public class AI_Definite {
    private static final String PROXY_HOST = "proxy.onyx.com";
    private static final int PROXY_PORT = 8080;
    
    private Proxy proxy;
    
    public AI_Definite() {
        initializeProxy();
    }
    
    private void initializeProxy() {
        proxy = new Proxy(
            Proxy.Type.HTTP,
            new InetSocketAddress(PROXY_HOST, PROXY_PORT)
        );
    }
    
    public Proxy getProxy() {
        return proxy;
    }
    
    public void setCustomProxy(String host, int port) {
        proxy = new Proxy(
            Proxy.Type.HTTP,
            new InetSocketAddress(host, port)
        );
    }
    
    public boolean isProxyAvailable() {
        try {
            return ((InetSocketAddress)proxy.address()).getAddress().isReachable(5000);
        } catch (Exception e) {
            return false;
        }
    }
}
